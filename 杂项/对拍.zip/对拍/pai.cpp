#include<bits/stdc++.h>
using namespace std;
int main() {
    system("g++ -std=c++11 gen.cpp -o gen");
    system("g++ std.cpp -o std");
    system("g++ my.cpp -o my");
    long long cnt=0;
    while(1) {
        system("./gen > data.in");
        system("./my <data.in >my.out");
        system("./std <data.in >std.out");
        if(system("diff std.out my.out")) {
            printf("WA!!!");break;
        }
        else {
            printf("#AC : %lld\n",++cnt);
        }
    }
    return 0;
}

