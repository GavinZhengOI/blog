#include<bits/stdc++.h>
using namespace std;
mt19937 Rnd(chrono::high_resolution_clock::now().time_since_epoch().count());
int main() {
    for(int i=1;i<=200000;i++)cout<<(char)(Rnd()%26+'a');
    cout<<endl;
    for(int i=1;i<=200000;i++)cout<<(char)(Rnd()%26+'a');
    return 0;
}
